import turtle
t = turtle.Turtle()
t.reset()
t.pu()
t.ht()
t.pensize(1)
t.speed(7)
color = ['red','yellow','blue','green','pink','orange']
def block():
    global color
    while True:
        b = input('请输入你要画的图形的边数')
        while True:
            if not b.isdigit():
                b = input('请输入数字!')
            else:
                b = int(b)
                break
        c = ''
        if b > 20:
            while True:
                check = input('输入的数字过大，会导致图形不完整且近似于圆（可以使用画圆模块），是否要继续呢？（y/n）')
                if check == 'y':
                    c = 'yes'
                    break
                elif check == 'n':
                    c = 'no'
                    break
                else:
                    print('输入错误请重新输入(y代表是，n代表否)')
            if c == 'yes':
                break
            elif c == 'no':
                continue
        else:
            break
    c = input('请输入你要画的'+str(b)+'边形的个数')
    while True:
        if not c.isdigit():
            c = input('请输入数字!')
        else:
            c = int(c)
            break
    gets = 1
    get = 3
    t.pd()
    for i in range(c):
        t.color(color[i%6])
        t.fillcolor(color[i%6])
        t.begin_fill()
        for i in range(b):
            t.forward(20)
            t.right(360/b)
        t.end_fill()
        t.pu()
        t.forward(b*5)
        if (i+1)%gets == 0:
            t.right(90)
            t.forward(b*8)
            gets += 1
        if gets == get:
            gets = get-1
            get += 1
        t.pd()
def star():
    global color
    n = input('请输入你要画的星星的个数')
    while True:
        if not n.isdigit():
            n = input('请输入数字!')
        else:
            n = int(n)
            break
    gets = 1
    get = 3
    t.goto(100,100)
    t.right(54)
    t.pd()
    for i in range(n):
        t.color(color[i%6])
        t.fillcolor(color[i%6])
        t.begin_fill()
        for j in range(5):
            t.forward(30)
            t.right(144)
        t.end_fill()
        t.pu()
        t.forward(30)
        if (i+1)%gets == 0:
            t.right(90)
            t.forward(50)
            gets += 1
        if gets == get:
            gets = get-1
            get += 1
        t.pd()
awa = 0
def end(n):
        if n == 0:
            input('画图已完成，按enter退出')
        elif n == 1:
            waw = input('>>>')
            if waw == 'awa':
                    print('你已经触犯了我,哦.是该程序的底线！快走，别让我赶你！')
                    for i in range(100):
                        input('>>>')
                    print('好吧，你真有毅力，那么，再见吧！')
                    for j in range(100):
                        input('>>>')
                    print('还不走！！！你再不走我要赶你了！')
                    for i in range(16):
                        input('>>>')
                    print('算了，你可能也没耐心了，跟你说吧，你每次画东西我都知道,我就没想说你，这还变本加厉，想画114514个爱心（好臭啊），我告诉你，下次不能这样了啊！(在这样我嘎了你)')
                    input('画图已完成，按enter键退出')
def circle():
    d = input('请输入你要画的圆的直径')
    while True:
        if not d.isdigit():
            d = input('请输入数字!')
        else:
            d = int(d)
            break
    e = input('请输入你要画的圆的个数')
    while True:
        if not e.isdigit():
            e = input('请输入数字!')
        else:
            e = int(e)
            break
    gets = 1
    get = 3
    t.pd()
    for i in range(e):
        t.color(color[i%6])
        t.fillcolor(color[i%6])
        t.begin_fill()
        t.circle(d//2)
        t.end_fill()
        t.pu()
        t.forward(d)
        if (i+1)%gets == 0:
            t.right(90)
            t.forward(d*2)
            gets += 1
        if gets == get:
            gets = get-1
            get += 1
        t.pd()
def curvemove():
    for i in range(100):
        turtle.right(2)
        turtle.forward(0.5)
        turtle.speed(10)
#版权声明：本代码为CSDN博主「诛心人i」的原创，遵循CC 4.0 BY-SA版权协议，
#原代码链接：https://blog.csdn.net/qq_43764365/article/details/97389619
def heart():
    a = input('请输入你要画的爱心的个数')
    b = 0
    while True:
        if not a.isdigit():
            a = input('请输入数字!')
        elif a == '114514':
            awa = 1
            b = 1
            break
        else:
            a = int(a)
            break
    if b == 0:
        gets = 1
        get = 3
        for i in range(a):
            turtle.color(('#F05B72'), 'red')
            turtle.begin_fill()
            turtle.left(140)
            turtle.pendown()
            turtle.forward(111.65/4)
            curvemove()
            turtle.left(120)
            curvemove()
            turtle.forward(111.65/4)
            turtle.end_fill()
            turtle.penup()
            turtle.forward((i+1)*40)
    elif b == 1:
        curvemove()
        for i in range(60):
            turtle.left(6)
        turtle.penup()
        for j in range(20):
            turtle.forward(10)
        turtle.hideturtle()
        return 1
#版权声明：本代码为CSDN博主「诛心人i」的原创，遵循CC 4.0 BY-SA版权协议，
#原代码链接：https://blog.csdn.net/qq_43764365/article/details/97389619
def flower():
    t = turtle.Turtle()
    a = int(input('请输入你要画的花的花瓣数'))
    while True:
        if not str(a).isdigit():
            a = input('请输入数字!')
        else:
            a = int(a)
            break
    t.color('red')
    t.fillcolor('yellow')
    t.begin_fill()
    for i in range(a):
        for i in range(91):
            t.right(2)
            t.forward(0.5)
        t.left(180-360/a+2)
    t.end_fill()
print('1.5.11版更新公告:\n1.成立文件夹，将python的下载链接放入文件夹\n2.加入检测模块，乱输入也不会报错啦\n3.修改画花功能\n4.优化已知问题，增强用户体验')
while True:
    a = input('欢迎使用海龟图正式版1.5.3，请选择模式:\n任意多边形（1）\n五角星（2）\n圆形（3）\n爱心（4）\n花（5）\n')
    if a == '1':
        block()
        break
    elif a == '2':
        star()
        break
    elif a == '3':
        circle()
        break
    elif a == '4':
        awa = heart()
        break
    elif a == '5':
        flower()
        break
    else:
        print('输入错误，请再次选择!')
end(awa)
